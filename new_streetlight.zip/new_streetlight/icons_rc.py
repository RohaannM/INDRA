# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01*\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22white\x22 str\
oke-width=\x223\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22 cla\
ss=\x22feather feat\
her-message-squa\
re\x22><path d=\x22M21\
 15a2 2 0 0 1-2 \
2H7l-4 4V5a2 2 0\
 0 1 2-2h14a2 2 \
0 0 1 2 2z\x22></pa\
th></svg>\
\x00\x00\x03\xec\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22white\x22 str\
oke-width=\x223\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22 cla\
ss=\x22feather feat\
her-settings\x22><c\
ircle cx=\x2212\x22 cy\
=\x2212\x22 r=\x223\x22></ci\
rcle><path d=\x22M1\
9.4 15a1.65 1.65\
 0 0 0 .33 1.82l\
.06.06a2 2 0 0 1\
 0 2.83 2 2 0 0 \
1-2.83 0l-.06-.0\
6a1.65 1.65 0 0 \
0-1.82-.33 1.65 \
1.65 0 0 0-1 1.5\
1V21a2 2 0 0 1-2\
 2 2 2 0 0 1-2-2\
v-.09A1.65 1.65 \
0 0 0 9 19.4a1.6\
5 1.65 0 0 0-1.8\
2.33l-.06.06a2 2\
 0 0 1-2.83 0 2 \
2 0 0 1 0-2.83l.\
06-.06a1.65 1.65\
 0 0 0 .33-1.82 \
1.65 1.65 0 0 0-\
1.51-1H3a2 2 0 0\
 1-2-2 2 2 0 0 1\
 2-2h.09A1.65 1.\
65 0 0 0 4.6 9a1\
.65 1.65 0 0 0-.\
33-1.82l-.06-.06\
a2 2 0 0 1 0-2.8\
3 2 2 0 0 1 2.83\
 0l.06.06a1.65 1\
.65 0 0 0 1.82.3\
3H9a1.65 1.65 0 \
0 0 1-1.51V3a2 2\
 0 0 1 2-2 2 2 0\
 0 1 2 2v.09a1.6\
5 1.65 0 0 0 1 1\
.51 1.65 1.65 0 \
0 0 1.82-.33l.06\
-.06a2 2 0 0 1 2\
.83 0 2 2 0 0 1 \
0 2.83l-.06.06a1\
.65 1.65 0 0 0-.\
33 1.82V9a1.65 1\
.65 0 0 0 1.51 1\
H21a2 2 0 0 1 2 \
2 2 2 0 0 1-2 2h\
-.09a1.65 1.65 0\
 0 0-1.51 1z\x22></\
path></svg>\
\x00\x00\x01\x13\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22white\x22 str\
oke-width=\x223\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22 cla\
ss=\x22feather feat\
her-activity\x22><p\
olyline points=\x22\
22 12 18 12 15 2\
1 9 3 6 12 2 12\x22\
></polyline></sv\
g>\
\x00\x00\x01S\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22white\x22 str\
oke-width=\x223\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22 cla\
ss=\x22feather feat\
her-menu\x22><line \
x1=\x223\x22 y1=\x2212\x22 x\
2=\x2221\x22 y2=\x2212\x22><\
/line><line x1=\x22\
3\x22 y1=\x226\x22 x2=\x2221\
\x22 y2=\x226\x22></line>\
<line x1=\x223\x22 y1=\
\x2218\x22 x2=\x2221\x22 y2=\
\x2218\x22></line></sv\
g>\
\x00\x00\x01:\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22white\x22 str\
oke-width=\x223\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22 cla\
ss=\x22feather feat\
her-bell\x22><path \
d=\x22M18 8A6 6 0 0\
 0 6 8c0 7-3 9-3\
 9h18s-3-2-3-9\x22>\
</path><path d=\x22\
M13.73 21a2 2 0 \
0 1-3.46 0\x22></pa\
th></svg>\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x12\
\x0e\xff\xaeg\
\x00m\
\x00e\x00s\x00s\x00a\x00g\x00e\x00-\x00s\x00q\x00u\x00a\x00r\x00e\x00.\x00s\x00v\
\x00g\
\x00\x0c\
\x0b\xdf,\xc7\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0cQ;g\
\x00a\
\x00c\x00t\x00i\x00v\x00i\x00t\x00y\x00.\x00s\x00v\x00g\
\x00\x08\
\x0cXT\xa7\
\x00m\
\x00e\x00n\x00u\x00.\x00s\x00v\x00g\
\x00\x0c\
\x06$\x06\x87\
\x00b\
\x00e\x00l\x00l\x00 \x00(\x001\x00)\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x05\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x8c\x00\x00\x00\x00\x00\x01\x00\x00\x07\x8c\
\x00\x00\x01\x90\xdbRf\x92\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\x01.\
\x00\x00\x01\x90\xdbT\x8a\x99\
\x00\x00\x00X\x00\x00\x00\x00\x00\x01\x00\x00\x05\x1e\
\x00\x00\x01\x90\xdbTb\x0a\
\x00\x00\x00v\x00\x00\x00\x00\x00\x01\x00\x00\x065\
\x00\x00\x01\x90\xdbTN2\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x90\xdbT\xa5\xe1\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
